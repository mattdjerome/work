#!/bin/bash


/Library/Application\ Support/JAMF/bin/jamfHelper.app/Contents/MacOS/jamfHelper -windowType hud -title "Important Message" -description "You have a message from IT. Have a nice day!" -icon "/System/Library/CoreServices/CoreTypes.bundle/Contents/Resources/public.generic-pc.icns"