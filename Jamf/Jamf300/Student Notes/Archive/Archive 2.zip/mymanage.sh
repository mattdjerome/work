#!/bin/bash

/usr/local/jamf/bin/jamf manage
date +%F\ %T >> /Users/Shared/managementTime.txt