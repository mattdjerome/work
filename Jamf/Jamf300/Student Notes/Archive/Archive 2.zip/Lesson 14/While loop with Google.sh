#!/bin/bash

while [[ -d /Applications/Google\ Chrome.app/ ]];do
	echo "The app is here. It must go!"
	sleep 3 
done
echo "It looks like Google Chrome is gone. Great job."