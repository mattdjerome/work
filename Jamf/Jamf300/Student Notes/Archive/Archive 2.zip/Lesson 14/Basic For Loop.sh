#!/bin/bash

for i in red green blue;do
	echo "The color is $i"
	sleep 1
done
	