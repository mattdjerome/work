#!/bin/bash

#defaults read /Library/LaunchDaemons/com.jamfsoftware.task.1.plist Label

