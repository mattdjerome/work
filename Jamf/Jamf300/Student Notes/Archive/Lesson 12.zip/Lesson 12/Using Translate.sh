#!/bin/bash

#Translate
#echo "Leet Speak" | tr e 3

#networksetup -help
#networksetup -listallhardwareports 
#networksetup -listallhardwareports | awk '/Ethernet Address:/{print $NF}' 
#networksetup -listallhardwareports | awk '/Ethernet Address:/{print $NF}' | tr "[:lower:]" "[:upper:]"