#!/bin/bash

Parameters: 
Mountpoint=$1 
ComputerName=$2 
Username=$3 