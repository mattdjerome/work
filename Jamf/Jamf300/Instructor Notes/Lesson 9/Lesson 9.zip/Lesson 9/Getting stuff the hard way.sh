#!/bin/bash
#Gets code requirement
#codesign --display --requirements - /Applications/Google\ Chrome.app/

#Gets the bundle id
osascript -e 'id of app "Google Chrome"'