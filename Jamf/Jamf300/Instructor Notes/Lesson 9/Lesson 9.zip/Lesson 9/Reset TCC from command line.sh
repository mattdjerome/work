#!/bin/bash

#tccutil reset All

#tccutil reset All com.apple.Terminal

tccutil reset All com.google.chrome